# Telegram Firebase Device Viewer (Node.js / Vercel)

This is a Node.js conversion of the supplied PHP webhook bot. It is **read-only**: it lists and searches device records under Firebase `clients/.json`. It does not send SMS or run commands on devices.

## Files

- `api/webhook.js` — Vercel serverless Telegram webhook.
- `vercel.json` — routes `/webhook` to the function.
- `package.json` — Node.js dependency.

## Required environment variables

Set these in Vercel Project → Settings → Environment Variables:

- `BOT_TOKEN` — a newly generated Telegram bot token. Do not reuse the token that was hardcoded in the PHP file because it was exposed.
- `OWNER_ID` — Telegram numeric user ID allowed to control the bot (the supplied PHP file used `8865308850`; verify this is still yours before setting it).
- `UPSTASH_REDIS_REST_URL` — Upstash Redis REST URL.
- `UPSTASH_REDIS_REST_TOKEN` — Upstash Redis REST token.
- `WEBHOOK_SECRET` — optional random secret for validating Telegram webhook requests.

Upstash Redis is required because Vercel serverless files are temporary. Firebase URLs and channel IDs added through bot commands are stored in Redis and persist across deployments.

## Deploy

1. Push this folder's contents to a new GitHub repository (the `api` folder must be at the repository root).
2. Import that repository into Vercel.
3. Add the environment variables above and deploy.
4. Set the Telegram webhook to `https://api.telegram.org/bot<YOUR_NEW_BOT_TOKEN>/setWebhook?url=https://<YOUR-VERCEL-DOMAIN>/webhook`.
5. If you set `WEBHOOK_SECRET`, use Telegram's `setWebhook` JSON method and include `secret_token` with the same value.
6. Open `https://<YOUR-VERCEL-DOMAIN>/webhook` in a browser; it should say the webhook is running.

## Bot commands

- `/start` or `/help`
- `/status`
- `/firebase`
- `/addfirebase URL | NAME`
- `/setfirebase NUMBER`
- `/channel`
- `/addchannel ID | NAME`
- `/setchannel NUMBER`
- `/devices`
- `/device MODEL`

The channel ID is saved for selection/status only; this bot does not post device data to channels.
