import { Redis } from '@upstash/redis';

const redis = Redis.fromEnv();
const CONFIG_KEY = 'telegram-firebase-device-viewer:config:v1';
const HELP = `🤖 BOT CONTROL\n\n/start or /help - commands\n/status - saved configuration\n/firebase - list saved Firebase URLs\n/addfirebase URL | NAME - add Firebase\n/setfirebase NUMBER - select Firebase\n/channel - list saved chat/channel IDs\n/addchannel ID | NAME - save chat/channel ID\n/setchannel NUMBER - select chat/channel\n/devices - read-only device list\n/device MODEL - search by model name\n\nDevice information is view-only. SMS sending and remote device commands are not included.`;

function defaultConfig() {
  return { firebases: [], channels: [], active_firebase: 0, active_channel: 0 };
}

async function loadConfig() {
  return (await redis.get(CONFIG_KEY)) ?? defaultConfig();
}

async function saveConfig(config) {
  await redis.set(CONFIG_KEY, config);
}

async function telegram(method, payload) {
  const token = process.env.BOT_TOKEN;
  if (!token) throw new Error('BOT_TOKEN environment variable is missing.');
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(20000)
  });
  const result = await response.json();
  if (!response.ok || !result.ok) throw new Error(result.description || `Telegram HTTP ${response.status}`);
  return result;
}

async function send(chatId, message) {
  await telegram('sendMessage', { chat_id: chatId, text: String(message).slice(0, 4000) });
}

function splitPair(value) {
  const index = value.indexOf('|');
  if (index < 0) return [null, null];
  const left = value.slice(0, index).trim();
  const right = value.slice(index + 1).trim();
  return left ? [left, right] : [null, null];
}

function activeFirebase(config) {
  if (!config.firebases.length) return null;
  const index = Number(config.active_firebase) || 0;
  return config.firebases[index] ?? config.firebases[0];
}

function modelOf(info) {
  if (!info || typeof info !== 'object') return 'Unknown Model';
  return String(info.modelName ?? info.model ?? info.deviceName ?? 'Unknown Model');
}

function deviceText(id, info) {
  info = info && typeof info === 'object' ? info : {};
  const status = info.status ? '🟢 Online' : '⚪ Status unknown/offline';
  return `📱 ${modelOf(info)}\n🆔 Device ID: ${id}\n🔋 Battery: ${info.battery ?? '—'}\n🤖 Android: ${info.androidV ?? info.androidVersion ?? '—'}\nStatus: ${status}`;
}

async function firebaseDevices(config) {
  const fb = activeFirebase(config);
  if (!fb) throw new Error('No Firebase saved. First use /addfirebase URL | NAME');
  const response = await fetch(`${fb.url.replace(/\/+$/, '')}/clients/.json`, {
    signal: AbortSignal.timeout(20000)
  });
  if (!response.ok) throw new Error(`Firebase HTTP ${response.status}`);
  const data = await response.json();
  return data && typeof data === 'object' ? data : {};
}

async function handleMessage(message) {
  const chat = message.chat ?? {};
  const user = message.from ?? {};
  const chatId = chat.id;
  const ownerId = process.env.OWNER_ID;
  if (chat.type !== 'private' || String(user.id) !== String(ownerId ?? '')) {
    if (chatId !== undefined) await send(chatId, '⛔ Access denied. Owner-only private control.');
    return;
  }

  const input = String(message.text ?? '').trim();
  if (!input) return;
  const [rawCommand, ...rest] = input.split(/\s+/);
  const command = rawCommand.toLowerCase().split('@')[0];
  const args = input.slice(rawCommand.length).trim();
  const config = await loadConfig();

  try {
    switch (command) {
      case '/start':
      case '/help':
        await send(chatId, HELP);
        break;

      case '/status': {
        const fb = activeFirebase(config);
        const channelIndex = Number(config.active_channel) || 0;
        const channel = config.channels[channelIndex] ?? null;
        await send(chatId, `⚙️ STATUS\nFirebase saved: ${config.firebases.length}\nActive Firebase: ${fb?.name ?? 'Not set'}\nChannels saved: ${config.channels.length}\nActive channel: ${channel?.name ?? 'Not set'}\nDevice access: read-only`);
        break;
      }

      case '/firebase':
        if (!config.firebases.length) {
          await send(chatId, 'No Firebase saved. Add:\n/addfirebase https://your-db.firebaseio.com | My Firebase');
        } else {
          const lines = ['🔥 SAVED FIREBASES'];
          config.firebases.forEach((item, index) => lines.push(`${index + 1}. ${item.name}${index === Number(config.active_firebase) ? ' ⭐' : ''}\n${item.url}`));
          await send(chatId, lines.join('\n'));
        }
        break;

      case '/addfirebase': {
        const [urlValue, nameValue] = splitPair(args);
        if (!urlValue || !/^https?:\/\//i.test(urlValue)) {
          await send(chatId, 'Format:\n/addfirebase https://your-db.firebaseio.com | My Firebase');
          break;
        }
        const url = urlValue.replace(/\/+$/, '');
        const name = nameValue || url;
        const existing = config.firebases.findIndex(item => String(item.url).replace(/\/+$/, '') === url);
        if (existing >= 0) config.firebases[existing].name = name;
        else {
          config.firebases.push({ name, url });
          config.active_firebase = config.firebases.length - 1;
        }
        await saveConfig(config);
        await send(chatId, `✅ Firebase saved: ${name}`);
        break;
      }

      case '/setfirebase': {
        const number = Number.parseInt(args, 10);
        if (!Number.isInteger(number) || number < 1 || number > config.firebases.length) {
          await send(chatId, 'Use /firebase, then /setfirebase NUMBER');
          break;
        }
        config.active_firebase = number - 1;
        await saveConfig(config);
        await send(chatId, `✅ Selected: ${config.firebases[number - 1].name}`);
        break;
      }

      case '/channel':
        if (!config.channels.length) await send(chatId, 'No channel saved. Add:\n/addchannel -1001234567890 | My Channel');
        else {
          const lines = ['💬 SAVED CHANNELS'];
          config.channels.forEach((item, index) => lines.push(`${index + 1}. ${item.name} — ${item.id}${index === Number(config.active_channel) ? ' ⭐' : ''}`));
          await send(chatId, lines.join('\n'));
        }
        break;

      case '/addchannel': {
        const [idValue, nameValue] = splitPair(args);
        if (idValue === null || !/^-?\d+$/.test(idValue)) {
          await send(chatId, 'Format:\n/addchannel -1001234567890 | My Channel');
          break;
        }
        const id = idValue;
        const name = nameValue || id;
        const existing = config.channels.findIndex(item => String(item.id) === id);
        if (existing >= 0) config.channels[existing].name = name;
        else {
          config.channels.push({ name, id });
          config.active_channel = config.channels.length - 1;
        }
        await saveConfig(config);
        await send(chatId, `✅ Channel saved: ${name}`);
        break;
      }

      case '/setchannel': {
        const number = Number.parseInt(args, 10);
        if (!Number.isInteger(number) || number < 1 || number > config.channels.length) {
          await send(chatId, 'Use /channel, then /setchannel NUMBER');
          break;
        }
        config.active_channel = number - 1;
        await saveConfig(config);
        await send(chatId, `✅ Selected: ${config.channels[number - 1].name}`);
        break;
      }

      case '/devices': {
        const devices = await firebaseDevices(config);
        const entries = Object.entries(devices);
        if (!entries.length) await send(chatId, 'No records found under /clients.');
        else {
          const lines = [`📱 DEVICES (${entries.length})`];
          for (const [id, info] of entries.slice(0, 30)) lines.push(`\n${deviceText(id, info)}`);
          if (entries.length > 30) lines.push(`\nShowing 30 of ${entries.length}. Search with /device MODEL`);
          await send(chatId, lines.join('\n'));
        }
        break;
      }

      case '/device': {
        if (!args) {
          await send(chatId, 'Use: /device MODEL_NAME');
          break;
        }
        const devices = await firebaseDevices(config);
        const matches = Object.entries(devices).filter(([, info]) => modelOf(info).toLowerCase().includes(args.toLowerCase()));
        if (!matches.length) await send(chatId, `No model matching '${args}' found.`);
        else await send(chatId, `🔎 Matches: ${matches.length}\n\n${matches.slice(0, 15).map(([id, info]) => deviceText(id, info)).join('\n\n')}`);
        break;
      }

      default:
        await send(chatId, 'Unknown command. Use /help.');
    }
  } catch (error) {
    const messageText = String(error?.message ?? error).slice(0, 350);
    await send(chatId, `Request failed: ${messageText}`);
  }
}

export default async function handler(req, res) {
  if (req.method === 'GET') return res.status(200).send('Telegram webhook is running.');
  if (req.method !== 'POST') return res.status(405).send('Method not allowed');

  const secret = process.env.WEBHOOK_SECRET;
  if (secret && req.headers['x-telegram-bot-api-secret-token'] !== secret) {
    return res.status(401).send('Unauthorized');
  }

  try {
    const update = req.body && typeof req.body === 'object' ? req.body : {};
    if (update.message && typeof update.message === 'object') await handleMessage(update.message);
    return res.status(200).send('OK');
  } catch (error) {
    console.error('Webhook error:', error?.message ?? error);
    return res.status(200).send('OK');
  }
}
